################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/examples/others/xml/lv_example_xml_1.c \
../lvgl/examples/others/xml/lv_example_xml_2.c 

C_DEPS += \
./lvgl/examples/others/xml/lv_example_xml_1.d \
./lvgl/examples/others/xml/lv_example_xml_2.d 

OBJS += \
./lvgl/examples/others/xml/lv_example_xml_1.o \
./lvgl/examples/others/xml/lv_example_xml_2.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/examples/others/xml/%.o lvgl/examples/others/xml/%.su lvgl/examples/others/xml/%.cyclo: ../lvgl/examples/others/xml/%.c lvgl/examples/others/xml/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-examples-2f-others-2f-xml

clean-lvgl-2f-examples-2f-others-2f-xml:
	-$(RM) ./lvgl/examples/others/xml/lv_example_xml_1.cyclo ./lvgl/examples/others/xml/lv_example_xml_1.d ./lvgl/examples/others/xml/lv_example_xml_1.o ./lvgl/examples/others/xml/lv_example_xml_1.su ./lvgl/examples/others/xml/lv_example_xml_2.cyclo ./lvgl/examples/others/xml/lv_example_xml_2.d ./lvgl/examples/others/xml/lv_example_xml_2.o ./lvgl/examples/others/xml/lv_example_xml_2.su

.PHONY: clean-lvgl-2f-examples-2f-others-2f-xml

