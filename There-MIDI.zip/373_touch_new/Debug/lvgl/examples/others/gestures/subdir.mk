################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/examples/others/gestures/lv_example_gestures.c 

C_DEPS += \
./lvgl/examples/others/gestures/lv_example_gestures.d 

OBJS += \
./lvgl/examples/others/gestures/lv_example_gestures.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/examples/others/gestures/%.o lvgl/examples/others/gestures/%.su lvgl/examples/others/gestures/%.cyclo: ../lvgl/examples/others/gestures/%.c lvgl/examples/others/gestures/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-examples-2f-others-2f-gestures

clean-lvgl-2f-examples-2f-others-2f-gestures:
	-$(RM) ./lvgl/examples/others/gestures/lv_example_gestures.cyclo ./lvgl/examples/others/gestures/lv_example_gestures.d ./lvgl/examples/others/gestures/lv_example_gestures.o ./lvgl/examples/others/gestures/lv_example_gestures.su

.PHONY: clean-lvgl-2f-examples-2f-others-2f-gestures

