################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/examples/widgets/arclabel/lv_example_arclabel_1.c 

C_DEPS += \
./lvgl/examples/widgets/arclabel/lv_example_arclabel_1.d 

OBJS += \
./lvgl/examples/widgets/arclabel/lv_example_arclabel_1.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/examples/widgets/arclabel/%.o lvgl/examples/widgets/arclabel/%.su lvgl/examples/widgets/arclabel/%.cyclo: ../lvgl/examples/widgets/arclabel/%.c lvgl/examples/widgets/arclabel/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-examples-2f-widgets-2f-arclabel

clean-lvgl-2f-examples-2f-widgets-2f-arclabel:
	-$(RM) ./lvgl/examples/widgets/arclabel/lv_example_arclabel_1.cyclo ./lvgl/examples/widgets/arclabel/lv_example_arclabel_1.d ./lvgl/examples/widgets/arclabel/lv_example_arclabel_1.o ./lvgl/examples/widgets/arclabel/lv_example_arclabel_1.su

.PHONY: clean-lvgl-2f-examples-2f-widgets-2f-arclabel

