################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb565.c \
../lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb888.c 

C_DEPS += \
./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb565.d \
./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb888.d 

OBJS += \
./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb565.o \
./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb888.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/src/draw/sw/blend/neon/%.o lvgl/src/draw/sw/blend/neon/%.su lvgl/src/draw/sw/blend/neon/%.cyclo: ../lvgl/src/draw/sw/blend/neon/%.c lvgl/src/draw/sw/blend/neon/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-src-2f-draw-2f-sw-2f-blend-2f-neon

clean-lvgl-2f-src-2f-draw-2f-sw-2f-blend-2f-neon:
	-$(RM) ./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb565.cyclo ./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb565.d ./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb565.o ./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb565.su ./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb888.cyclo ./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb888.d ./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb888.o ./lvgl/src/draw/sw/blend/neon/lv_draw_sw_blend_neon_to_rgb888.su

.PHONY: clean-lvgl-2f-src-2f-draw-2f-sw-2f-blend-2f-neon

