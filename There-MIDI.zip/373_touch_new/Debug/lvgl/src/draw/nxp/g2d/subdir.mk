################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/src/draw/nxp/g2d/lv_draw_buf_g2d.c \
../lvgl/src/draw/nxp/g2d/lv_draw_g2d.c \
../lvgl/src/draw/nxp/g2d/lv_draw_g2d_fill.c \
../lvgl/src/draw/nxp/g2d/lv_draw_g2d_img.c \
../lvgl/src/draw/nxp/g2d/lv_g2d_buf_map.c \
../lvgl/src/draw/nxp/g2d/lv_g2d_utils.c 

C_DEPS += \
./lvgl/src/draw/nxp/g2d/lv_draw_buf_g2d.d \
./lvgl/src/draw/nxp/g2d/lv_draw_g2d.d \
./lvgl/src/draw/nxp/g2d/lv_draw_g2d_fill.d \
./lvgl/src/draw/nxp/g2d/lv_draw_g2d_img.d \
./lvgl/src/draw/nxp/g2d/lv_g2d_buf_map.d \
./lvgl/src/draw/nxp/g2d/lv_g2d_utils.d 

OBJS += \
./lvgl/src/draw/nxp/g2d/lv_draw_buf_g2d.o \
./lvgl/src/draw/nxp/g2d/lv_draw_g2d.o \
./lvgl/src/draw/nxp/g2d/lv_draw_g2d_fill.o \
./lvgl/src/draw/nxp/g2d/lv_draw_g2d_img.o \
./lvgl/src/draw/nxp/g2d/lv_g2d_buf_map.o \
./lvgl/src/draw/nxp/g2d/lv_g2d_utils.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/src/draw/nxp/g2d/%.o lvgl/src/draw/nxp/g2d/%.su lvgl/src/draw/nxp/g2d/%.cyclo: ../lvgl/src/draw/nxp/g2d/%.c lvgl/src/draw/nxp/g2d/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-src-2f-draw-2f-nxp-2f-g2d

clean-lvgl-2f-src-2f-draw-2f-nxp-2f-g2d:
	-$(RM) ./lvgl/src/draw/nxp/g2d/lv_draw_buf_g2d.cyclo ./lvgl/src/draw/nxp/g2d/lv_draw_buf_g2d.d ./lvgl/src/draw/nxp/g2d/lv_draw_buf_g2d.o ./lvgl/src/draw/nxp/g2d/lv_draw_buf_g2d.su ./lvgl/src/draw/nxp/g2d/lv_draw_g2d.cyclo ./lvgl/src/draw/nxp/g2d/lv_draw_g2d.d ./lvgl/src/draw/nxp/g2d/lv_draw_g2d.o ./lvgl/src/draw/nxp/g2d/lv_draw_g2d.su ./lvgl/src/draw/nxp/g2d/lv_draw_g2d_fill.cyclo ./lvgl/src/draw/nxp/g2d/lv_draw_g2d_fill.d ./lvgl/src/draw/nxp/g2d/lv_draw_g2d_fill.o ./lvgl/src/draw/nxp/g2d/lv_draw_g2d_fill.su ./lvgl/src/draw/nxp/g2d/lv_draw_g2d_img.cyclo ./lvgl/src/draw/nxp/g2d/lv_draw_g2d_img.d ./lvgl/src/draw/nxp/g2d/lv_draw_g2d_img.o ./lvgl/src/draw/nxp/g2d/lv_draw_g2d_img.su ./lvgl/src/draw/nxp/g2d/lv_g2d_buf_map.cyclo ./lvgl/src/draw/nxp/g2d/lv_g2d_buf_map.d ./lvgl/src/draw/nxp/g2d/lv_g2d_buf_map.o ./lvgl/src/draw/nxp/g2d/lv_g2d_buf_map.su ./lvgl/src/draw/nxp/g2d/lv_g2d_utils.cyclo ./lvgl/src/draw/nxp/g2d/lv_g2d_utils.d ./lvgl/src/draw/nxp/g2d/lv_g2d_utils.o ./lvgl/src/draw/nxp/g2d/lv_g2d_utils.su

.PHONY: clean-lvgl-2f-src-2f-draw-2f-nxp-2f-g2d

