################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/src/xml/lv_xml.c \
../lvgl/src/xml/lv_xml_base_types.c \
../lvgl/src/xml/lv_xml_component.c \
../lvgl/src/xml/lv_xml_load.c \
../lvgl/src/xml/lv_xml_parser.c \
../lvgl/src/xml/lv_xml_style.c \
../lvgl/src/xml/lv_xml_test.c \
../lvgl/src/xml/lv_xml_translation.c \
../lvgl/src/xml/lv_xml_update.c \
../lvgl/src/xml/lv_xml_utils.c \
../lvgl/src/xml/lv_xml_widget.c 

C_DEPS += \
./lvgl/src/xml/lv_xml.d \
./lvgl/src/xml/lv_xml_base_types.d \
./lvgl/src/xml/lv_xml_component.d \
./lvgl/src/xml/lv_xml_load.d \
./lvgl/src/xml/lv_xml_parser.d \
./lvgl/src/xml/lv_xml_style.d \
./lvgl/src/xml/lv_xml_test.d \
./lvgl/src/xml/lv_xml_translation.d \
./lvgl/src/xml/lv_xml_update.d \
./lvgl/src/xml/lv_xml_utils.d \
./lvgl/src/xml/lv_xml_widget.d 

OBJS += \
./lvgl/src/xml/lv_xml.o \
./lvgl/src/xml/lv_xml_base_types.o \
./lvgl/src/xml/lv_xml_component.o \
./lvgl/src/xml/lv_xml_load.o \
./lvgl/src/xml/lv_xml_parser.o \
./lvgl/src/xml/lv_xml_style.o \
./lvgl/src/xml/lv_xml_test.o \
./lvgl/src/xml/lv_xml_translation.o \
./lvgl/src/xml/lv_xml_update.o \
./lvgl/src/xml/lv_xml_utils.o \
./lvgl/src/xml/lv_xml_widget.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/src/xml/%.o lvgl/src/xml/%.su lvgl/src/xml/%.cyclo: ../lvgl/src/xml/%.c lvgl/src/xml/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-src-2f-xml

clean-lvgl-2f-src-2f-xml:
	-$(RM) ./lvgl/src/xml/lv_xml.cyclo ./lvgl/src/xml/lv_xml.d ./lvgl/src/xml/lv_xml.o ./lvgl/src/xml/lv_xml.su ./lvgl/src/xml/lv_xml_base_types.cyclo ./lvgl/src/xml/lv_xml_base_types.d ./lvgl/src/xml/lv_xml_base_types.o ./lvgl/src/xml/lv_xml_base_types.su ./lvgl/src/xml/lv_xml_component.cyclo ./lvgl/src/xml/lv_xml_component.d ./lvgl/src/xml/lv_xml_component.o ./lvgl/src/xml/lv_xml_component.su ./lvgl/src/xml/lv_xml_load.cyclo ./lvgl/src/xml/lv_xml_load.d ./lvgl/src/xml/lv_xml_load.o ./lvgl/src/xml/lv_xml_load.su ./lvgl/src/xml/lv_xml_parser.cyclo ./lvgl/src/xml/lv_xml_parser.d ./lvgl/src/xml/lv_xml_parser.o ./lvgl/src/xml/lv_xml_parser.su ./lvgl/src/xml/lv_xml_style.cyclo ./lvgl/src/xml/lv_xml_style.d ./lvgl/src/xml/lv_xml_style.o ./lvgl/src/xml/lv_xml_style.su ./lvgl/src/xml/lv_xml_test.cyclo ./lvgl/src/xml/lv_xml_test.d ./lvgl/src/xml/lv_xml_test.o ./lvgl/src/xml/lv_xml_test.su ./lvgl/src/xml/lv_xml_translation.cyclo ./lvgl/src/xml/lv_xml_translation.d ./lvgl/src/xml/lv_xml_translation.o ./lvgl/src/xml/lv_xml_translation.su ./lvgl/src/xml/lv_xml_update.cyclo ./lvgl/src/xml/lv_xml_update.d ./lvgl/src/xml/lv_xml_update.o ./lvgl/src/xml/lv_xml_update.su ./lvgl/src/xml/lv_xml_utils.cyclo ./lvgl/src/xml/lv_xml_utils.d ./lvgl/src/xml/lv_xml_utils.o ./lvgl/src/xml/lv_xml_utils.su ./lvgl/src/xml/lv_xml_widget.cyclo ./lvgl/src/xml/lv_xml_widget.d ./lvgl/src/xml/lv_xml_widget.o ./lvgl/src/xml/lv_xml_widget.su

.PHONY: clean-lvgl-2f-src-2f-xml

