################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/src/drivers/qnx/lv_qnx.c 

C_DEPS += \
./lvgl/src/drivers/qnx/lv_qnx.d 

OBJS += \
./lvgl/src/drivers/qnx/lv_qnx.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/src/drivers/qnx/%.o lvgl/src/drivers/qnx/%.su lvgl/src/drivers/qnx/%.cyclo: ../lvgl/src/drivers/qnx/%.c lvgl/src/drivers/qnx/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-src-2f-drivers-2f-qnx

clean-lvgl-2f-src-2f-drivers-2f-qnx:
	-$(RM) ./lvgl/src/drivers/qnx/lv_qnx.cyclo ./lvgl/src/drivers/qnx/lv_qnx.d ./lvgl/src/drivers/qnx/lv_qnx.o ./lvgl/src/drivers/qnx/lv_qnx.su

.PHONY: clean-lvgl-2f-src-2f-drivers-2f-qnx

