################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/src/libs/gltf/gltf_environment/lv_gltf_ibl_sampler.c 

C_DEPS += \
./lvgl/src/libs/gltf/gltf_environment/lv_gltf_ibl_sampler.d 

OBJS += \
./lvgl/src/libs/gltf/gltf_environment/lv_gltf_ibl_sampler.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/src/libs/gltf/gltf_environment/%.o lvgl/src/libs/gltf/gltf_environment/%.su lvgl/src/libs/gltf/gltf_environment/%.cyclo: ../lvgl/src/libs/gltf/gltf_environment/%.c lvgl/src/libs/gltf/gltf_environment/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-src-2f-libs-2f-gltf-2f-gltf_environment

clean-lvgl-2f-src-2f-libs-2f-gltf-2f-gltf_environment:
	-$(RM) ./lvgl/src/libs/gltf/gltf_environment/lv_gltf_ibl_sampler.cyclo ./lvgl/src/libs/gltf/gltf_environment/lv_gltf_ibl_sampler.d ./lvgl/src/libs/gltf/gltf_environment/lv_gltf_ibl_sampler.o ./lvgl/src/libs/gltf/gltf_environment/lv_gltf_ibl_sampler.su

.PHONY: clean-lvgl-2f-src-2f-libs-2f-gltf-2f-gltf_environment

