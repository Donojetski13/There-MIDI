################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/src/libs/libwebp/lv_libwebp.c 

C_DEPS += \
./lvgl/src/libs/libwebp/lv_libwebp.d 

OBJS += \
./lvgl/src/libs/libwebp/lv_libwebp.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/src/libs/libwebp/%.o lvgl/src/libs/libwebp/%.su lvgl/src/libs/libwebp/%.cyclo: ../lvgl/src/libs/libwebp/%.c lvgl/src/libs/libwebp/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-src-2f-libs-2f-libwebp

clean-lvgl-2f-src-2f-libs-2f-libwebp:
	-$(RM) ./lvgl/src/libs/libwebp/lv_libwebp.cyclo ./lvgl/src/libs/libwebp/lv_libwebp.d ./lvgl/src/libs/libwebp/lv_libwebp.o ./lvgl/src/libs/libwebp/lv_libwebp.su

.PHONY: clean-lvgl-2f-src-2f-libs-2f-libwebp

