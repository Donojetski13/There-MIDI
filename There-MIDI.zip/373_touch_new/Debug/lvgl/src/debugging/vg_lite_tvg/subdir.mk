################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
CPP_SRCS += \
../lvgl/src/debugging/vg_lite_tvg/vg_lite_tvg.cpp 

C_SRCS += \
../lvgl/src/debugging/vg_lite_tvg/vg_lite_matrix.c 

C_DEPS += \
./lvgl/src/debugging/vg_lite_tvg/vg_lite_matrix.d 

OBJS += \
./lvgl/src/debugging/vg_lite_tvg/vg_lite_matrix.o \
./lvgl/src/debugging/vg_lite_tvg/vg_lite_tvg.o 

CPP_DEPS += \
./lvgl/src/debugging/vg_lite_tvg/vg_lite_tvg.d 


# Each subdirectory must supply rules for building sources it contributes
lvgl/src/debugging/vg_lite_tvg/%.o lvgl/src/debugging/vg_lite_tvg/%.su lvgl/src/debugging/vg_lite_tvg/%.cyclo: ../lvgl/src/debugging/vg_lite_tvg/%.c lvgl/src/debugging/vg_lite_tvg/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"
lvgl/src/debugging/vg_lite_tvg/%.o lvgl/src/debugging/vg_lite_tvg/%.su lvgl/src/debugging/vg_lite_tvg/%.cyclo: ../lvgl/src/debugging/vg_lite_tvg/%.cpp lvgl/src/debugging/vg_lite_tvg/subdir.mk
	arm-none-eabi-g++ "$<" -mcpu=cortex-m4 -std=gnu++14 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I"D:/new_373_project/373_touch_new/lvgl" -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -O0 -ffunction-sections -fdata-sections -fno-exceptions -fno-rtti -fno-use-cxa-atexit -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-src-2f-debugging-2f-vg_lite_tvg

clean-lvgl-2f-src-2f-debugging-2f-vg_lite_tvg:
	-$(RM) ./lvgl/src/debugging/vg_lite_tvg/vg_lite_matrix.cyclo ./lvgl/src/debugging/vg_lite_tvg/vg_lite_matrix.d ./lvgl/src/debugging/vg_lite_tvg/vg_lite_matrix.o ./lvgl/src/debugging/vg_lite_tvg/vg_lite_matrix.su ./lvgl/src/debugging/vg_lite_tvg/vg_lite_tvg.cyclo ./lvgl/src/debugging/vg_lite_tvg/vg_lite_tvg.d ./lvgl/src/debugging/vg_lite_tvg/vg_lite_tvg.o ./lvgl/src/debugging/vg_lite_tvg/vg_lite_tvg.su

.PHONY: clean-lvgl-2f-src-2f-debugging-2f-vg_lite_tvg

