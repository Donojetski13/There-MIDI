################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/src/debugging/sysmon/lv_sysmon.c 

C_DEPS += \
./lvgl/src/debugging/sysmon/lv_sysmon.d 

OBJS += \
./lvgl/src/debugging/sysmon/lv_sysmon.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/src/debugging/sysmon/%.o lvgl/src/debugging/sysmon/%.su lvgl/src/debugging/sysmon/%.cyclo: ../lvgl/src/debugging/sysmon/%.c lvgl/src/debugging/sysmon/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-src-2f-debugging-2f-sysmon

clean-lvgl-2f-src-2f-debugging-2f-sysmon:
	-$(RM) ./lvgl/src/debugging/sysmon/lv_sysmon.cyclo ./lvgl/src/debugging/sysmon/lv_sysmon.d ./lvgl/src/debugging/sysmon/lv_sysmon.o ./lvgl/src/debugging/sysmon/lv_sysmon.su

.PHONY: clean-lvgl-2f-src-2f-debugging-2f-sysmon

