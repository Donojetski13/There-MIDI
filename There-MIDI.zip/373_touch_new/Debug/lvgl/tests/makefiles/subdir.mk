################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/tests/makefiles/test.c 

C_DEPS += \
./lvgl/tests/makefiles/test.d 

OBJS += \
./lvgl/tests/makefiles/test.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/tests/makefiles/%.o lvgl/tests/makefiles/%.su lvgl/tests/makefiles/%.cyclo: ../lvgl/tests/makefiles/%.c lvgl/tests/makefiles/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-tests-2f-makefiles

clean-lvgl-2f-tests-2f-makefiles:
	-$(RM) ./lvgl/tests/makefiles/test.cyclo ./lvgl/tests/makefiles/test.d ./lvgl/tests/makefiles/test.o ./lvgl/tests/makefiles/test.su

.PHONY: clean-lvgl-2f-tests-2f-makefiles

