################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/tests/src/test_cases/cache/test_cache.c 

C_DEPS += \
./lvgl/tests/src/test_cases/cache/test_cache.d 

OBJS += \
./lvgl/tests/src/test_cases/cache/test_cache.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/tests/src/test_cases/cache/%.o lvgl/tests/src/test_cases/cache/%.su lvgl/tests/src/test_cases/cache/%.cyclo: ../lvgl/tests/src/test_cases/cache/%.c lvgl/tests/src/test_cases/cache/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-tests-2f-src-2f-test_cases-2f-cache

clean-lvgl-2f-tests-2f-src-2f-test_cases-2f-cache:
	-$(RM) ./lvgl/tests/src/test_cases/cache/test_cache.cyclo ./lvgl/tests/src/test_cases/cache/test_cache.d ./lvgl/tests/src/test_cases/cache/test_cache.o ./lvgl/tests/src/test_cases/cache/test_cache.su

.PHONY: clean-lvgl-2f-tests-2f-src-2f-test_cases-2f-cache

