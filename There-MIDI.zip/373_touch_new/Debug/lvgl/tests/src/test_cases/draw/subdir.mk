################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../lvgl/tests/src/test_cases/draw/test_bg_image.c \
../lvgl/tests/src/test_cases/draw/test_clip_corner.c \
../lvgl/tests/src/test_cases/draw/test_draw_blend.c \
../lvgl/tests/src/test_cases/draw/test_draw_blur.c \
../lvgl/tests/src/test_cases/draw/test_draw_custom_handlers.c \
../lvgl/tests/src/test_cases/draw/test_draw_label.c \
../lvgl/tests/src/test_cases/draw/test_draw_layer.c \
../lvgl/tests/src/test_cases/draw/test_draw_letter.c \
../lvgl/tests/src/test_cases/draw/test_draw_svg.c \
../lvgl/tests/src/test_cases/draw/test_draw_sw_post_process.c \
../lvgl/tests/src/test_cases/draw/test_draw_vector.c \
../lvgl/tests/src/test_cases/draw/test_image_colorkey.c \
../lvgl/tests/src/test_cases/draw/test_image_formats.c \
../lvgl/tests/src/test_cases/draw/test_layer_transform.c \
../lvgl/tests/src/test_cases/draw/test_render_to_al88.c \
../lvgl/tests/src/test_cases/draw/test_render_to_argb1555.c \
../lvgl/tests/src/test_cases/draw/test_render_to_argb2222.c \
../lvgl/tests/src/test_cases/draw/test_render_to_argb4444.c \
../lvgl/tests/src/test_cases/draw/test_render_to_argb8888.c \
../lvgl/tests/src/test_cases/draw/test_render_to_argb8888_premultiplied.c \
../lvgl/tests/src/test_cases/draw/test_render_to_i1.c \
../lvgl/tests/src/test_cases/draw/test_render_to_l8.c \
../lvgl/tests/src/test_cases/draw/test_render_to_rgb565.c \
../lvgl/tests/src/test_cases/draw/test_render_to_rgb565_swapped.c \
../lvgl/tests/src/test_cases/draw/test_render_to_rgb888.c \
../lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.c 

C_DEPS += \
./lvgl/tests/src/test_cases/draw/test_bg_image.d \
./lvgl/tests/src/test_cases/draw/test_clip_corner.d \
./lvgl/tests/src/test_cases/draw/test_draw_blend.d \
./lvgl/tests/src/test_cases/draw/test_draw_blur.d \
./lvgl/tests/src/test_cases/draw/test_draw_custom_handlers.d \
./lvgl/tests/src/test_cases/draw/test_draw_label.d \
./lvgl/tests/src/test_cases/draw/test_draw_layer.d \
./lvgl/tests/src/test_cases/draw/test_draw_letter.d \
./lvgl/tests/src/test_cases/draw/test_draw_svg.d \
./lvgl/tests/src/test_cases/draw/test_draw_sw_post_process.d \
./lvgl/tests/src/test_cases/draw/test_draw_vector.d \
./lvgl/tests/src/test_cases/draw/test_image_colorkey.d \
./lvgl/tests/src/test_cases/draw/test_image_formats.d \
./lvgl/tests/src/test_cases/draw/test_layer_transform.d \
./lvgl/tests/src/test_cases/draw/test_render_to_al88.d \
./lvgl/tests/src/test_cases/draw/test_render_to_argb1555.d \
./lvgl/tests/src/test_cases/draw/test_render_to_argb2222.d \
./lvgl/tests/src/test_cases/draw/test_render_to_argb4444.d \
./lvgl/tests/src/test_cases/draw/test_render_to_argb8888.d \
./lvgl/tests/src/test_cases/draw/test_render_to_argb8888_premultiplied.d \
./lvgl/tests/src/test_cases/draw/test_render_to_i1.d \
./lvgl/tests/src/test_cases/draw/test_render_to_l8.d \
./lvgl/tests/src/test_cases/draw/test_render_to_rgb565.d \
./lvgl/tests/src/test_cases/draw/test_render_to_rgb565_swapped.d \
./lvgl/tests/src/test_cases/draw/test_render_to_rgb888.d \
./lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.d 

OBJS += \
./lvgl/tests/src/test_cases/draw/test_bg_image.o \
./lvgl/tests/src/test_cases/draw/test_clip_corner.o \
./lvgl/tests/src/test_cases/draw/test_draw_blend.o \
./lvgl/tests/src/test_cases/draw/test_draw_blur.o \
./lvgl/tests/src/test_cases/draw/test_draw_custom_handlers.o \
./lvgl/tests/src/test_cases/draw/test_draw_label.o \
./lvgl/tests/src/test_cases/draw/test_draw_layer.o \
./lvgl/tests/src/test_cases/draw/test_draw_letter.o \
./lvgl/tests/src/test_cases/draw/test_draw_svg.o \
./lvgl/tests/src/test_cases/draw/test_draw_sw_post_process.o \
./lvgl/tests/src/test_cases/draw/test_draw_vector.o \
./lvgl/tests/src/test_cases/draw/test_image_colorkey.o \
./lvgl/tests/src/test_cases/draw/test_image_formats.o \
./lvgl/tests/src/test_cases/draw/test_layer_transform.o \
./lvgl/tests/src/test_cases/draw/test_render_to_al88.o \
./lvgl/tests/src/test_cases/draw/test_render_to_argb1555.o \
./lvgl/tests/src/test_cases/draw/test_render_to_argb2222.o \
./lvgl/tests/src/test_cases/draw/test_render_to_argb4444.o \
./lvgl/tests/src/test_cases/draw/test_render_to_argb8888.o \
./lvgl/tests/src/test_cases/draw/test_render_to_argb8888_premultiplied.o \
./lvgl/tests/src/test_cases/draw/test_render_to_i1.o \
./lvgl/tests/src/test_cases/draw/test_render_to_l8.o \
./lvgl/tests/src/test_cases/draw/test_render_to_rgb565.o \
./lvgl/tests/src/test_cases/draw/test_render_to_rgb565_swapped.o \
./lvgl/tests/src/test_cases/draw/test_render_to_rgb888.o \
./lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.o 


# Each subdirectory must supply rules for building sources it contributes
lvgl/tests/src/test_cases/draw/%.o lvgl/tests/src/test_cases/draw/%.su lvgl/tests/src/test_cases/draw/%.cyclo: ../lvgl/tests/src/test_cases/draw/%.c lvgl/tests/src/test_cases/draw/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/lvgl" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-lvgl-2f-tests-2f-src-2f-test_cases-2f-draw

clean-lvgl-2f-tests-2f-src-2f-test_cases-2f-draw:
	-$(RM) ./lvgl/tests/src/test_cases/draw/test_bg_image.cyclo ./lvgl/tests/src/test_cases/draw/test_bg_image.d ./lvgl/tests/src/test_cases/draw/test_bg_image.o ./lvgl/tests/src/test_cases/draw/test_bg_image.su ./lvgl/tests/src/test_cases/draw/test_clip_corner.cyclo ./lvgl/tests/src/test_cases/draw/test_clip_corner.d ./lvgl/tests/src/test_cases/draw/test_clip_corner.o ./lvgl/tests/src/test_cases/draw/test_clip_corner.su ./lvgl/tests/src/test_cases/draw/test_draw_blend.cyclo ./lvgl/tests/src/test_cases/draw/test_draw_blend.d ./lvgl/tests/src/test_cases/draw/test_draw_blend.o ./lvgl/tests/src/test_cases/draw/test_draw_blend.su ./lvgl/tests/src/test_cases/draw/test_draw_blur.cyclo ./lvgl/tests/src/test_cases/draw/test_draw_blur.d ./lvgl/tests/src/test_cases/draw/test_draw_blur.o ./lvgl/tests/src/test_cases/draw/test_draw_blur.su ./lvgl/tests/src/test_cases/draw/test_draw_custom_handlers.cyclo ./lvgl/tests/src/test_cases/draw/test_draw_custom_handlers.d ./lvgl/tests/src/test_cases/draw/test_draw_custom_handlers.o ./lvgl/tests/src/test_cases/draw/test_draw_custom_handlers.su ./lvgl/tests/src/test_cases/draw/test_draw_label.cyclo ./lvgl/tests/src/test_cases/draw/test_draw_label.d ./lvgl/tests/src/test_cases/draw/test_draw_label.o ./lvgl/tests/src/test_cases/draw/test_draw_label.su ./lvgl/tests/src/test_cases/draw/test_draw_layer.cyclo ./lvgl/tests/src/test_cases/draw/test_draw_layer.d ./lvgl/tests/src/test_cases/draw/test_draw_layer.o ./lvgl/tests/src/test_cases/draw/test_draw_layer.su ./lvgl/tests/src/test_cases/draw/test_draw_letter.cyclo ./lvgl/tests/src/test_cases/draw/test_draw_letter.d ./lvgl/tests/src/test_cases/draw/test_draw_letter.o ./lvgl/tests/src/test_cases/draw/test_draw_letter.su ./lvgl/tests/src/test_cases/draw/test_draw_svg.cyclo ./lvgl/tests/src/test_cases/draw/test_draw_svg.d ./lvgl/tests/src/test_cases/draw/test_draw_svg.o ./lvgl/tests/src/test_cases/draw/test_draw_svg.su ./lvgl/tests/src/test_cases/draw/test_draw_sw_post_process.cyclo ./lvgl/tests/src/test_cases/draw/test_draw_sw_post_process.d ./lvgl/tests/src/test_cases/draw/test_draw_sw_post_process.o ./lvgl/tests/src/test_cases/draw/test_draw_sw_post_process.su ./lvgl/tests/src/test_cases/draw/test_draw_vector.cyclo ./lvgl/tests/src/test_cases/draw/test_draw_vector.d ./lvgl/tests/src/test_cases/draw/test_draw_vector.o ./lvgl/tests/src/test_cases/draw/test_draw_vector.su ./lvgl/tests/src/test_cases/draw/test_image_colorkey.cyclo ./lvgl/tests/src/test_cases/draw/test_image_colorkey.d ./lvgl/tests/src/test_cases/draw/test_image_colorkey.o ./lvgl/tests/src/test_cases/draw/test_image_colorkey.su ./lvgl/tests/src/test_cases/draw/test_image_formats.cyclo ./lvgl/tests/src/test_cases/draw/test_image_formats.d ./lvgl/tests/src/test_cases/draw/test_image_formats.o ./lvgl/tests/src/test_cases/draw/test_image_formats.su ./lvgl/tests/src/test_cases/draw/test_layer_transform.cyclo ./lvgl/tests/src/test_cases/draw/test_layer_transform.d ./lvgl/tests/src/test_cases/draw/test_layer_transform.o ./lvgl/tests/src/test_cases/draw/test_layer_transform.su ./lvgl/tests/src/test_cases/draw/test_render_to_al88.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_al88.d ./lvgl/tests/src/test_cases/draw/test_render_to_al88.o ./lvgl/tests/src/test_cases/draw/test_render_to_al88.su ./lvgl/tests/src/test_cases/draw/test_render_to_argb1555.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_argb1555.d ./lvgl/tests/src/test_cases/draw/test_render_to_argb1555.o ./lvgl/tests/src/test_cases/draw/test_render_to_argb1555.su ./lvgl/tests/src/test_cases/draw/test_render_to_argb2222.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_argb2222.d ./lvgl/tests/src/test_cases/draw/test_render_to_argb2222.o ./lvgl/tests/src/test_cases/draw/test_render_to_argb2222.su ./lvgl/tests/src/test_cases/draw/test_render_to_argb4444.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_argb4444.d ./lvgl/tests/src/test_cases/draw/test_render_to_argb4444.o ./lvgl/tests/src/test_cases/draw/test_render_to_argb4444.su ./lvgl/tests/src/test_cases/draw/test_render_to_argb8888.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_argb8888.d ./lvgl/tests/src/test_cases/draw/test_render_to_argb8888.o ./lvgl/tests/src/test_cases/draw/test_render_to_argb8888.su ./lvgl/tests/src/test_cases/draw/test_render_to_argb8888_premultiplied.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_argb8888_premultiplied.d ./lvgl/tests/src/test_cases/draw/test_render_to_argb8888_premultiplied.o ./lvgl/tests/src/test_cases/draw/test_render_to_argb8888_premultiplied.su ./lvgl/tests/src/test_cases/draw/test_render_to_i1.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_i1.d ./lvgl/tests/src/test_cases/draw/test_render_to_i1.o ./lvgl/tests/src/test_cases/draw/test_render_to_i1.su ./lvgl/tests/src/test_cases/draw/test_render_to_l8.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_l8.d ./lvgl/tests/src/test_cases/draw/test_render_to_l8.o ./lvgl/tests/src/test_cases/draw/test_render_to_l8.su ./lvgl/tests/src/test_cases/draw/test_render_to_rgb565.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_rgb565.d ./lvgl/tests/src/test_cases/draw/test_render_to_rgb565.o ./lvgl/tests/src/test_cases/draw/test_render_to_rgb565.su ./lvgl/tests/src/test_cases/draw/test_render_to_rgb565_swapped.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_rgb565_swapped.d ./lvgl/tests/src/test_cases/draw/test_render_to_rgb565_swapped.o ./lvgl/tests/src/test_cases/draw/test_render_to_rgb565_swapped.su ./lvgl/tests/src/test_cases/draw/test_render_to_rgb888.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_rgb888.d ./lvgl/tests/src/test_cases/draw/test_render_to_rgb888.o ./lvgl/tests/src/test_cases/draw/test_render_to_rgb888.su ./lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.cyclo ./lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.d ./lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.o ./lvgl/tests/src/test_cases/draw/test_render_to_xrgb8888.su

.PHONY: clean-lvgl-2f-tests-2f-src-2f-test_cases-2f-draw

