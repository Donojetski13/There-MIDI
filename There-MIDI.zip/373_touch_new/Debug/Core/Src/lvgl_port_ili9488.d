Core/Src/lvgl_port_ili9488.o: ../Core/Src/lvgl_port_ili9488.c \
 D:/new_373_project/373_touch_new/lvgl/lvgl.h \
 D:/new_373_project/373_touch_new/lvgl/lv_version.h \
 D:/new_373_project/373_touch_new/lvgl/src/lv_init.h \
 D:/new_373_project/373_touch_new/lvgl/src/lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/lv_conf_kconfig.h \
 D:/new_373_project/373_touch_new/lvgl/src/../../lv_conf.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/stdlib/lv_mem.h \
 D:/new_373_project/373_touch_new/lvgl/src/stdlib/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/stdlib/lv_string.h \
 D:/new_373_project/373_touch_new/lvgl/src/stdlib/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/stdlib/lv_string.h \
 D:/new_373_project/373_touch_new/lvgl/src/stdlib/lv_sprintf.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_log.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_timer.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../tick/lv_tick.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../tick/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../tick/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_ll.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_math.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_array.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_async.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_anim_timeline.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_anim.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_math.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_timer.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_profiler_builtin.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_rb.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_assert.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_log.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../stdlib/lv_mem.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_utils.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/lv_draw_buf.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_area.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_math.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_color.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_assert.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_palette.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_color.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_color_op.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../stdlib/lv_string.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/lv_image_dsc.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_iter.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_circle_buf.h \
 D:/new_373_project/373_touch_new/lvgl/src/misc/lv_tree.h \
 D:/new_373_project/373_touch_new/lvgl/src/osal/lv_os.h \
 D:/new_373_project/373_touch_new/lvgl/src/osal/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/tick/lv_tick.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_style.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/lv_font.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/lv_symbol_def.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/../draw/lv_draw_buf.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/../misc/lv_area.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_color.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_area.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_anim.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_text.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../stdlib/lv_sprintf.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_assert.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_bidi.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_grad.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/lv_layout.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/flex/lv_flex.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/flex/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/flex/../../misc/lv_area.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/grid/lv_grid.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/grid/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/grid/../../misc/lv_area.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_style_gen.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_area.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_color.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_assert.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_tree.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_anim.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_timer.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_event.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_array.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_color.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_area.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_pos.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_scroll.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_style.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_bidi.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_style_gen.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../core/lv_obj_style.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_draw.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_rect.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_style.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_text.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_profiler.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_matrix.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_event.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_image_decoder.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_buf.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_fs.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_area.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_color.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_label.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_rect.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_bidi.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_image.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_line.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_arc.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_triangle.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_blur.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_class.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_property.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_event.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_event.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../core/lv_group.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../core/../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../core/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../core/../misc/lv_ll.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../misc/lv_area.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../misc/lv_timer.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../misc/lv_event.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_group.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_group.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_refr.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/core/lv_observer.h \
 D:/new_373_project/373_touch_new/lvgl/src/indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/indev/lv_indev_gesture.h \
 D:/new_373_project/373_touch_new/lvgl/src/indev/../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/indev/lv_gridnav.h \
 D:/new_373_project/373_touch_new/lvgl/src/display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/font/lv_font.h \
 D:/new_373_project/373_touch_new/lvgl/src/font/binfont_loader/lv_binfont_loader.h \
 D:/new_373_project/373_touch_new/lvgl/src/font/fmt_txt/lv_font_fmt_txt.h \
 D:/new_373_project/373_touch_new/lvgl/src/font/fmt_txt/../lv_font.h \
 D:/new_373_project/373_touch_new/lvgl/src/font/fmt_txt/../../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/font/imgfont/lv_imgfont.h \
 D:/new_373_project/373_touch_new/lvgl/src/font/imgfont/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/font/imgfont/../../font/lv_font.h \
 D:/new_373_project/373_touch_new/lvgl/src/font/font_manager/lv_font_manager.h \
 D:/new_373_project/373_touch_new/lvgl/src/font/font_manager/../../font/lv_font.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/lv_animimage.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/lv_image.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/../../misc/lv_fs.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/../../draw/lv_draw.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/../../core/lv_observer.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/arc/lv_arc.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/arc/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/arc/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/arc/../../core/lv_observer.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/arclabel/lv_arclabel.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/arclabel/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/lv_bar.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../../misc/lv_anim.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/lv_label.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../font/lv_font.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../font/lv_symbol_def.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../misc/lv_text.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../draw/lv_draw.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../core/lv_observer.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../../core/lv_observer.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/button/lv_button.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/button/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/button/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/buttonmatrix/lv_buttonmatrix.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/buttonmatrix/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/buttonmatrix/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/lv_calendar.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/../buttonmatrix/lv_buttonmatrix.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/lv_calendar_header_arrow.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/lv_calendar_header_dropdown.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/lv_calendar_chinese.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/lv_calendar.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/canvas/lv_canvas.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/canvas/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/canvas/../image/lv_image.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/canvas/../../draw/lv_draw_image.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/chart/lv_chart.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/chart/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/chart/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/checkbox/lv_checkbox.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/checkbox/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/checkbox/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/dropdown/lv_dropdown.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/dropdown/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/dropdown/../label/lv_label.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/image/lv_image.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/imagebutton/lv_imagebutton.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/imagebutton/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/keyboard/lv_keyboard.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/keyboard/../buttonmatrix/lv_buttonmatrix.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/label/lv_label.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/led/lv_led.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/led/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/line/lv_line.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/line/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/list/lv_list.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/list/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/lottie/lv_lottie.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/lottie/../../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/menu/lv_menu.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/menu/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/msgbox/lv_msgbox.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/msgbox/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/roller/lv_roller.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/roller/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/roller/../label/lv_label.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/lv_scale.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/../line/lv_line.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/../image/lv_image.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/../../core/lv_observer.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/slider/lv_slider.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/slider/../bar/lv_bar.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/span/lv_span.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/span/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/span/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/span/../../core/lv_observer.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/spinbox/lv_spinbox.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/spinbox/../textarea/lv_textarea.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/spinbox/../textarea/../label/lv_label.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/spinner/lv_spinner.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/spinner/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/spinner/../../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/switch/lv_switch.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/switch/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/switch/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/table/lv_table.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/table/../label/lv_label.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/tabview/lv_tabview.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/tabview/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/tabview/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/textarea/lv_textarea.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/tileview/lv_tileview.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/tileview/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/win/lv_win.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/win/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/win/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/3dtexture/lv_3dtexture.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/3dtexture/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/ime/lv_ime_pinyin.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/ime/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/widgets/ime/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/xml/lv_xml.h \
 D:/new_373_project/373_touch_new/lvgl/src/xml/../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/debugging/sysmon/lv_sysmon.h \
 D:/new_373_project/373_touch_new/lvgl/src/debugging/sysmon/../../misc/lv_timer.h \
 D:/new_373_project/373_touch_new/lvgl/src/debugging/sysmon/../../core/lv_observer.h \
 D:/new_373_project/373_touch_new/lvgl/src/debugging/monkey/lv_monkey.h \
 D:/new_373_project/373_touch_new/lvgl/src/debugging/monkey/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/debugging/monkey/../../indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/debugging/test/lv_test.h \
 D:/new_373_project/373_touch_new/lvgl/src/debugging/test/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/others/fragment/lv_fragment.h \
 D:/new_373_project/373_touch_new/lvgl/src/others/fragment/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/others/file_explorer/lv_file_explorer.h \
 D:/new_373_project/373_touch_new/lvgl/src/others/file_explorer/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/others/file_explorer/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/others/translation/lv_translation.h \
 D:/new_373_project/373_touch_new/lvgl/src/others/translation/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/barcode/lv_barcode.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/barcode/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/barcode/../../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/barcode/../../misc/lv_color.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/barcode/../../widgets/canvas/lv_canvas.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/bin_decoder/lv_bin_decoder.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/bin_decoder/../../draw/lv_image_decoder.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/bmp/lv_bmp.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/bmp/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/rle/lv_rle.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/rle/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/fsdrv/lv_fsdrv.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/fsdrv/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/lodepng/lv_lodepng.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/lodepng/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/libpng/lv_libpng.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/libpng/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/libwebp/lv_libwebp.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/libwebp/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/gltf/gltf_data/lv_gltf_model.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/gltf/gltf_data/../../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/gltf/gltf_view/lv_gltf.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/gltf/gltf_view/../../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/gif/lv_gif.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/gif/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/gif/../../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/gstreamer/lv_gstreamer.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/gstreamer/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/qrcode/lv_qrcode.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/qrcode/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/qrcode/../../misc/lv_color.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/qrcode/../../misc/lv_types.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/qrcode/../../widgets/canvas/lv_canvas.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/tjpgd/lv_tjpgd.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/libjpeg_turbo/lv_libjpeg_turbo.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/libjpeg_turbo/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/freetype/lv_freetype.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/freetype/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/rlottie/lv_rlottie.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/rlottie/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/ffmpeg/lv_ffmpeg.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/ffmpeg/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/tiny_ttf/lv_tiny_ttf.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/tiny_ttf/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/svg/lv_svg.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/svg/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/libs/svg/lv_svg_render.h \
 D:/new_373_project/373_touch_new/lvgl/src/layouts/lv_layout.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/lv_draw_buf.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/lv_draw_vector.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/../misc/lv_array.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/../misc/lv_matrix.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/lv_draw_image.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/sw/lv_draw_sw_utils.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/sw/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/sw/../../misc/lv_area.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/sw/../../misc/lv_color.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/sw/../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/eve/lv_draw_eve_target.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/eve/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/snapshot/lv_snapshot.h \
 D:/new_373_project/373_touch_new/lvgl/src/draw/snapshot/../../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/themes/lv_theme.h \
 D:/new_373_project/373_touch_new/lvgl/src/themes/../core/lv_obj.h \
 D:/new_373_project/373_touch_new/lvgl/src/themes/default/lv_theme_default.h \
 D:/new_373_project/373_touch_new/lvgl/src/themes/default/../lv_theme.h \
 D:/new_373_project/373_touch_new/lvgl/src/themes/mono/lv_theme_mono.h \
 D:/new_373_project/373_touch_new/lvgl/src/themes/mono/../lv_theme.h \
 D:/new_373_project/373_touch_new/lvgl/src/themes/simple/lv_theme_simple.h \
 D:/new_373_project/373_touch_new/lvgl/src/themes/simple/../lv_theme.h \
 D:/new_373_project/373_touch_new/lvgl/src/themes/simple/../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/lv_drivers.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/lv_sdl_window.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/../../indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/lv_sdl_mouse.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/lv_sdl_window.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/lv_sdl_mousewheel.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/lv_sdl_keyboard.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/x11/lv_x11.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/x11/../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/x11/../../indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/x11/../../draw/lv_image_dsc.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/drm/lv_linux_drm.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/drm/../../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/fb/lv_linux_fbdev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/fb/../../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/tft_espi/lv_tft_espi.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/tft_espi/../../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/lovyan_gfx/lv_lovyan_gfx.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/lovyan_gfx/../../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/lovyan_gfx/../../../indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/lcd/lv_lcd_generic_mipi.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/lcd/../../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/ili9341/lv_ili9341.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/ili9341/../lcd/lv_lcd_generic_mipi.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7735/lv_st7735.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7735/../lcd/lv_lcd_generic_mipi.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7789/lv_st7789.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7789/../lcd/lv_lcd_generic_mipi.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7796/lv_st7796.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7796/../lcd/lv_lcd_generic_mipi.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/nv3007/lv_nv3007.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/nv3007/../lcd/lv_lcd_generic_mipi.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/renesas_glcdc/lv_renesas_glcdc.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/renesas_glcdc/../../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st_ltdc/lv_st_ltdc.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st_ltdc/../../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/ft81x/lv_ft81x.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/display/ft81x/../../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/draw/eve/lv_draw_eve_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/draw/eve/../../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/draw/eve/lv_draw_eve_display_defines.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/lv_nuttx_entry.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/../../indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/lv_nuttx_fbdev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/lv_nuttx_touchscreen.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/lv_nuttx_lcd.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/lv_nuttx_libuv.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/evdev/lv_evdev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/evdev/../../indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/libinput/lv_libinput.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/libinput/../../indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/windows/lv_windows_input.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/windows/../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/windows/../../indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/windows/lv_windows_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/lv_opengles_window.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/lv_opengles_texture.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/lv_opengles_driver.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/lv_opengles_glfw.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/lv_opengles_egl.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/qnx/lv_qnx.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/qnx/../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/qnx/../../indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/wayland/lv_wayland.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/wayland/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/lv_uefi_context.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/../../lv_conf_internal.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/lv_uefi_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/../../indev/lv_indev.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/lv_uefi_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/../../display/lv_display.h \
 D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v8.h \
 D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v9_0.h \
 D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v9_1.h \
 D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v9_2.h \
 D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v9_3.h \
 D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v9_4.h \
 ../Core/Inc/ili9488.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal.h \
 ../Core/Inc/stm32l4xx_hal_conf.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l4r5xx.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32L4xx/Include/system_stm32l4xx.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc_ex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio_ex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_dma.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_ll_dma.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_ll_dmamux.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_dma_ex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_cortex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_exti.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ramfunc.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr_ex.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_spi.h \
 ../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_spi_ex.h \
 ../Core/Inc/main.h ../Core/Inc/ili9488.h ../Core/Inc/lvgl_port_ili9488.h \
 ../Core/Inc/../../lvgl/lvgl.h
D:/new_373_project/373_touch_new/lvgl/lvgl.h:
D:/new_373_project/373_touch_new/lvgl/lv_version.h:
D:/new_373_project/373_touch_new/lvgl/src/lv_init.h:
D:/new_373_project/373_touch_new/lvgl/src/lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/lv_conf_kconfig.h:
D:/new_373_project/373_touch_new/lvgl/src/../../lv_conf.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/stdlib/lv_mem.h:
D:/new_373_project/373_touch_new/lvgl/src/stdlib/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/stdlib/lv_string.h:
D:/new_373_project/373_touch_new/lvgl/src/stdlib/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/stdlib/lv_string.h:
D:/new_373_project/373_touch_new/lvgl/src/stdlib/lv_sprintf.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_log.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_timer.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../tick/lv_tick.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../tick/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../tick/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_ll.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_math.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_array.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_async.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_anim_timeline.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_anim.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_math.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_timer.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_profiler_builtin.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_rb.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_assert.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_log.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../stdlib/lv_mem.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_utils.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/lv_draw_buf.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_area.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_math.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_color.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_assert.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_palette.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_color.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../misc/lv_color_op.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../stdlib/lv_string.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/lv_image_dsc.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/../draw/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_iter.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_circle_buf.h:
D:/new_373_project/373_touch_new/lvgl/src/misc/lv_tree.h:
D:/new_373_project/373_touch_new/lvgl/src/osal/lv_os.h:
D:/new_373_project/373_touch_new/lvgl/src/osal/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/tick/lv_tick.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_style.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/lv_font.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/lv_symbol_def.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/../draw/lv_draw_buf.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../font/../misc/lv_area.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_color.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_area.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_anim.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_text.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../stdlib/lv_sprintf.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_assert.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_bidi.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_grad.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/lv_layout.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/flex/lv_flex.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/flex/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/flex/../../misc/lv_area.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/grid/lv_grid.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/grid/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/../layouts/grid/../../misc/lv_area.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_style_gen.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_area.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_color.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_assert.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_tree.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_anim.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_timer.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_event.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_array.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_color.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../display/../misc/lv_area.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_pos.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_scroll.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_style.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_bidi.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_style_gen.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../core/lv_obj_style.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_draw.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_rect.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_style.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_text.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_profiler.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_matrix.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_event.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_image_decoder.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_buf.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_fs.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_area.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_color.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_label.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_rect.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/../misc/lv_bidi.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_image.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_line.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_arc.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_triangle.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../draw/lv_draw_blur.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_class.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_property.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj_event.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../misc/lv_event.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../core/lv_group.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../core/../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../core/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../core/../misc/lv_ll.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../misc/lv_area.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../misc/lv_timer.h:
D:/new_373_project/373_touch_new/lvgl/src/core/../indev/../misc/lv_event.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_group.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_group.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_refr.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/core/lv_observer.h:
D:/new_373_project/373_touch_new/lvgl/src/indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/indev/lv_indev_gesture.h:
D:/new_373_project/373_touch_new/lvgl/src/indev/../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/indev/lv_gridnav.h:
D:/new_373_project/373_touch_new/lvgl/src/display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/font/lv_font.h:
D:/new_373_project/373_touch_new/lvgl/src/font/binfont_loader/lv_binfont_loader.h:
D:/new_373_project/373_touch_new/lvgl/src/font/fmt_txt/lv_font_fmt_txt.h:
D:/new_373_project/373_touch_new/lvgl/src/font/fmt_txt/../lv_font.h:
D:/new_373_project/373_touch_new/lvgl/src/font/fmt_txt/../../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/font/imgfont/lv_imgfont.h:
D:/new_373_project/373_touch_new/lvgl/src/font/imgfont/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/font/imgfont/../../font/lv_font.h:
D:/new_373_project/373_touch_new/lvgl/src/font/font_manager/lv_font_manager.h:
D:/new_373_project/373_touch_new/lvgl/src/font/font_manager/../../font/lv_font.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/lv_animimage.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/lv_image.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/../../misc/lv_fs.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/../../draw/lv_draw.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../image/../../core/lv_observer.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/animimage/../../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/arc/lv_arc.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/arc/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/arc/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/arc/../../core/lv_observer.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/arclabel/lv_arclabel.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/arclabel/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/lv_bar.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../../misc/lv_anim.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/lv_label.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../font/lv_font.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../font/lv_symbol_def.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../misc/lv_text.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../draw/lv_draw.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../label/../../core/lv_observer.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/bar/../../core/lv_observer.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/button/lv_button.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/button/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/button/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/buttonmatrix/lv_buttonmatrix.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/buttonmatrix/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/buttonmatrix/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/lv_calendar.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/../buttonmatrix/lv_buttonmatrix.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/lv_calendar_header_arrow.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/lv_calendar_header_dropdown.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/lv_calendar_chinese.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/calendar/lv_calendar.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/canvas/lv_canvas.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/canvas/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/canvas/../image/lv_image.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/canvas/../../draw/lv_draw_image.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/chart/lv_chart.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/chart/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/chart/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/checkbox/lv_checkbox.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/checkbox/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/checkbox/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/dropdown/lv_dropdown.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/dropdown/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/dropdown/../label/lv_label.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/image/lv_image.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/imagebutton/lv_imagebutton.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/imagebutton/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/keyboard/lv_keyboard.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/keyboard/../buttonmatrix/lv_buttonmatrix.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/label/lv_label.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/led/lv_led.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/led/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/line/lv_line.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/line/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/list/lv_list.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/list/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/lottie/lv_lottie.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/lottie/../../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/menu/lv_menu.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/menu/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/msgbox/lv_msgbox.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/msgbox/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/roller/lv_roller.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/roller/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/roller/../label/lv_label.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/lv_scale.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/../line/lv_line.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/../image/lv_image.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/scale/../../core/lv_observer.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/slider/lv_slider.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/slider/../bar/lv_bar.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/span/lv_span.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/span/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/span/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/span/../../core/lv_observer.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/spinbox/lv_spinbox.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/spinbox/../textarea/lv_textarea.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/spinbox/../textarea/../label/lv_label.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/spinner/lv_spinner.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/spinner/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/spinner/../../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/switch/lv_switch.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/switch/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/switch/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/table/lv_table.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/table/../label/lv_label.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/tabview/lv_tabview.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/tabview/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/tabview/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/textarea/lv_textarea.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/tileview/lv_tileview.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/tileview/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/win/lv_win.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/win/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/win/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/3dtexture/lv_3dtexture.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/3dtexture/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/ime/lv_ime_pinyin.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/ime/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/widgets/ime/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/xml/lv_xml.h:
D:/new_373_project/373_touch_new/lvgl/src/xml/../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/debugging/sysmon/lv_sysmon.h:
D:/new_373_project/373_touch_new/lvgl/src/debugging/sysmon/../../misc/lv_timer.h:
D:/new_373_project/373_touch_new/lvgl/src/debugging/sysmon/../../core/lv_observer.h:
D:/new_373_project/373_touch_new/lvgl/src/debugging/monkey/lv_monkey.h:
D:/new_373_project/373_touch_new/lvgl/src/debugging/monkey/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/debugging/monkey/../../indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/debugging/test/lv_test.h:
D:/new_373_project/373_touch_new/lvgl/src/debugging/test/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/others/fragment/lv_fragment.h:
D:/new_373_project/373_touch_new/lvgl/src/others/fragment/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/others/file_explorer/lv_file_explorer.h:
D:/new_373_project/373_touch_new/lvgl/src/others/file_explorer/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/others/file_explorer/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/others/translation/lv_translation.h:
D:/new_373_project/373_touch_new/lvgl/src/others/translation/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/barcode/lv_barcode.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/barcode/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/barcode/../../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/barcode/../../misc/lv_color.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/barcode/../../widgets/canvas/lv_canvas.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/bin_decoder/lv_bin_decoder.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/bin_decoder/../../draw/lv_image_decoder.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/bmp/lv_bmp.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/bmp/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/rle/lv_rle.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/rle/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/fsdrv/lv_fsdrv.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/fsdrv/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/lodepng/lv_lodepng.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/lodepng/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/libpng/lv_libpng.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/libpng/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/libwebp/lv_libwebp.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/libwebp/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/gltf/gltf_data/lv_gltf_model.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/gltf/gltf_data/../../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/gltf/gltf_view/lv_gltf.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/gltf/gltf_view/../../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/gif/lv_gif.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/gif/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/gif/../../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/gstreamer/lv_gstreamer.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/gstreamer/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/qrcode/lv_qrcode.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/qrcode/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/qrcode/../../misc/lv_color.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/qrcode/../../misc/lv_types.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/qrcode/../../widgets/canvas/lv_canvas.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/tjpgd/lv_tjpgd.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/libjpeg_turbo/lv_libjpeg_turbo.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/libjpeg_turbo/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/freetype/lv_freetype.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/freetype/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/rlottie/lv_rlottie.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/rlottie/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/ffmpeg/lv_ffmpeg.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/ffmpeg/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/tiny_ttf/lv_tiny_ttf.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/tiny_ttf/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/svg/lv_svg.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/svg/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/libs/svg/lv_svg_render.h:
D:/new_373_project/373_touch_new/lvgl/src/layouts/lv_layout.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/lv_draw_buf.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/lv_draw_vector.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/../misc/lv_array.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/../misc/lv_matrix.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/lv_draw_image.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/sw/lv_draw_sw_utils.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/sw/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/sw/../../misc/lv_area.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/sw/../../misc/lv_color.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/sw/../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/eve/lv_draw_eve_target.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/eve/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/snapshot/lv_snapshot.h:
D:/new_373_project/373_touch_new/lvgl/src/draw/snapshot/../../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/themes/lv_theme.h:
D:/new_373_project/373_touch_new/lvgl/src/themes/../core/lv_obj.h:
D:/new_373_project/373_touch_new/lvgl/src/themes/default/lv_theme_default.h:
D:/new_373_project/373_touch_new/lvgl/src/themes/default/../lv_theme.h:
D:/new_373_project/373_touch_new/lvgl/src/themes/mono/lv_theme_mono.h:
D:/new_373_project/373_touch_new/lvgl/src/themes/mono/../lv_theme.h:
D:/new_373_project/373_touch_new/lvgl/src/themes/simple/lv_theme_simple.h:
D:/new_373_project/373_touch_new/lvgl/src/themes/simple/../lv_theme.h:
D:/new_373_project/373_touch_new/lvgl/src/themes/simple/../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/lv_drivers.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/lv_sdl_window.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/../../indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/lv_sdl_mouse.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/lv_sdl_window.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/lv_sdl_mousewheel.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/sdl/lv_sdl_keyboard.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/x11/lv_x11.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/x11/../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/x11/../../indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/x11/../../draw/lv_image_dsc.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/drm/lv_linux_drm.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/drm/../../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/fb/lv_linux_fbdev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/fb/../../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/tft_espi/lv_tft_espi.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/tft_espi/../../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/lovyan_gfx/lv_lovyan_gfx.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/lovyan_gfx/../../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/lovyan_gfx/../../../indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/lcd/lv_lcd_generic_mipi.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/lcd/../../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/ili9341/lv_ili9341.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/ili9341/../lcd/lv_lcd_generic_mipi.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7735/lv_st7735.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7735/../lcd/lv_lcd_generic_mipi.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7789/lv_st7789.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7789/../lcd/lv_lcd_generic_mipi.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7796/lv_st7796.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st7796/../lcd/lv_lcd_generic_mipi.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/nv3007/lv_nv3007.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/nv3007/../lcd/lv_lcd_generic_mipi.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/renesas_glcdc/lv_renesas_glcdc.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/renesas_glcdc/../../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st_ltdc/lv_st_ltdc.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/st_ltdc/../../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/ft81x/lv_ft81x.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/display/ft81x/../../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/draw/eve/lv_draw_eve_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/draw/eve/../../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/draw/eve/lv_draw_eve_display_defines.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/lv_nuttx_entry.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/../../indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/lv_nuttx_fbdev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/lv_nuttx_touchscreen.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/lv_nuttx_lcd.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/nuttx/lv_nuttx_libuv.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/evdev/lv_evdev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/evdev/../../indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/libinput/lv_libinput.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/libinput/../../indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/windows/lv_windows_input.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/windows/../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/windows/../../indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/windows/lv_windows_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/lv_opengles_window.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/lv_opengles_texture.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/lv_opengles_driver.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/lv_opengles_glfw.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/opengles/lv_opengles_egl.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/qnx/lv_qnx.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/qnx/../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/qnx/../../indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/wayland/lv_wayland.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/wayland/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/lv_uefi_context.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/../../lv_conf_internal.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/lv_uefi_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/../../indev/lv_indev.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/lv_uefi_display.h:
D:/new_373_project/373_touch_new/lvgl/src/drivers/uefi/../../display/lv_display.h:
D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v8.h:
D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v9_0.h:
D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v9_1.h:
D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v9_2.h:
D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v9_3.h:
D:/new_373_project/373_touch_new/lvgl/src/lv_api_map_v9_4.h:
../Core/Inc/ili9488.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal.h:
../Core/Inc/stm32l4xx_hal_conf.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l4xx.h:
../Drivers/CMSIS/Device/ST/STM32L4xx/Include/stm32l4r5xx.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32L4xx/Include/system_stm32l4xx.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_rcc_ex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_gpio_ex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_dma.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_ll_dma.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_ll_dmamux.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_dma_ex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_cortex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_exti.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_flash_ramfunc.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_pwr_ex.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_spi.h:
../Drivers/STM32L4xx_HAL_Driver/Inc/stm32l4xx_hal_spi_ex.h:
../Core/Inc/main.h:
../Core/Inc/ili9488.h:
../Core/Inc/lvgl_port_ili9488.h:
../Core/Inc/../../lvgl/lvgl.h:
