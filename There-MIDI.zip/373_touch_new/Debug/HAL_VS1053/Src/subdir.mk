################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../HAL_VS1053/Src/MIDI_Player.c \
../HAL_VS1053/Src/VS1053.c 

C_DEPS += \
./HAL_VS1053/Src/MIDI_Player.d \
./HAL_VS1053/Src/VS1053.d 

OBJS += \
./HAL_VS1053/Src/MIDI_Player.o \
./HAL_VS1053/Src/VS1053.o 


# Each subdirectory must supply rules for building sources it contributes
HAL_VS1053/Src/%.o HAL_VS1053/Src/%.su HAL_VS1053/Src/%.cyclo: ../HAL_VS1053/Src/%.c HAL_VS1053/Src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/HAL_VS1053/Inc" -I"D:/new_373_project/373_touch_new/Platform" -I"D:/new_373_project/373_touch_new/VL53L7CX_ULD_API/inc" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-HAL_VS1053-2f-Src

clean-HAL_VS1053-2f-Src:
	-$(RM) ./HAL_VS1053/Src/MIDI_Player.cyclo ./HAL_VS1053/Src/MIDI_Player.d ./HAL_VS1053/Src/MIDI_Player.o ./HAL_VS1053/Src/MIDI_Player.su ./HAL_VS1053/Src/VS1053.cyclo ./HAL_VS1053/Src/VS1053.d ./HAL_VS1053/Src/VS1053.o ./HAL_VS1053/Src/VS1053.su

.PHONY: clean-HAL_VS1053-2f-Src

