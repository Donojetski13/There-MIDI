################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../VL53L7CX_ULD_API/src/vl53l7cx_api.c \
../VL53L7CX_ULD_API/src/vl53l7cx_plugin_detection_thresholds.c \
../VL53L7CX_ULD_API/src/vl53l7cx_plugin_motion_indicator.c 

C_DEPS += \
./VL53L7CX_ULD_API/src/vl53l7cx_api.d \
./VL53L7CX_ULD_API/src/vl53l7cx_plugin_detection_thresholds.d \
./VL53L7CX_ULD_API/src/vl53l7cx_plugin_motion_indicator.d 

OBJS += \
./VL53L7CX_ULD_API/src/vl53l7cx_api.o \
./VL53L7CX_ULD_API/src/vl53l7cx_plugin_detection_thresholds.o \
./VL53L7CX_ULD_API/src/vl53l7cx_plugin_motion_indicator.o 


# Each subdirectory must supply rules for building sources it contributes
VL53L7CX_ULD_API/src/%.o VL53L7CX_ULD_API/src/%.su VL53L7CX_ULD_API/src/%.cyclo: ../VL53L7CX_ULD_API/src/%.c VL53L7CX_ULD_API/src/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/HAL_VS1053/Inc" -I"D:/new_373_project/373_touch_new/Platform" -I"D:/new_373_project/373_touch_new/VL53L7CX_ULD_API/inc" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-VL53L7CX_ULD_API-2f-src

clean-VL53L7CX_ULD_API-2f-src:
	-$(RM) ./VL53L7CX_ULD_API/src/vl53l7cx_api.cyclo ./VL53L7CX_ULD_API/src/vl53l7cx_api.d ./VL53L7CX_ULD_API/src/vl53l7cx_api.o ./VL53L7CX_ULD_API/src/vl53l7cx_api.su ./VL53L7CX_ULD_API/src/vl53l7cx_plugin_detection_thresholds.cyclo ./VL53L7CX_ULD_API/src/vl53l7cx_plugin_detection_thresholds.d ./VL53L7CX_ULD_API/src/vl53l7cx_plugin_detection_thresholds.o ./VL53L7CX_ULD_API/src/vl53l7cx_plugin_detection_thresholds.su ./VL53L7CX_ULD_API/src/vl53l7cx_plugin_motion_indicator.cyclo ./VL53L7CX_ULD_API/src/vl53l7cx_plugin_motion_indicator.d ./VL53L7CX_ULD_API/src/vl53l7cx_plugin_motion_indicator.o ./VL53L7CX_ULD_API/src/vl53l7cx_plugin_motion_indicator.su

.PHONY: clean-VL53L7CX_ULD_API-2f-src

