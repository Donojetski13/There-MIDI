################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (12.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Platform/platform.c 

C_DEPS += \
./Platform/platform.d 

OBJS += \
./Platform/platform.o 


# Each subdirectory must supply rules for building sources it contributes
Platform/%.o Platform/%.su Platform/%.cyclo: ../Platform/%.c Platform/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32L4R5xx -c -I../Core/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc -I../Drivers/STM32L4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32L4xx/Include -I../Drivers/CMSIS/Include -I"D:/new_373_project/373_touch_new/HAL_VS1053/Inc" -I"D:/new_373_project/373_touch_new/Platform" -I"D:/new_373_project/373_touch_new/VL53L7CX_ULD_API/inc" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Platform

clean-Platform:
	-$(RM) ./Platform/platform.cyclo ./Platform/platform.d ./Platform/platform.o ./Platform/platform.su

.PHONY: clean-Platform

